function y=porte(x)
    y=abs(x)<0.5;
function y=triangle(x)
    y=(1-abs(x)).*(abs(x)<1);